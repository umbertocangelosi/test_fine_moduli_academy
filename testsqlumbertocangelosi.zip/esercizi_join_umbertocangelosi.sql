-- ESERCIZI JOIN UMBERTO CANGELOSI

-- 1 Scrivi una query per trovare nome, cognome, lavoro, ID reparto dei dipendenti che lavorano a Londra ed estrarre anche il nome reparto
SELECT FIRST_NAME, LAST_NAME, JOB_ID, d.DEPARTMENT_ID , DEPARTMENT_NAME
FROM employees as e
JOIN departments as d ON e.DEPARTMENT_ID= d.DEPARTMENT_ID
JOIN locations as l ON d.LOCATION_ID = l.LOCATION_ID
WHERE l.CITY = "London";


-- 2 Scrivi una query per trovare ID dipendente, cognome e relativo manager ID e cognome
SELECT e.EMPLOYEE_ID, e.LAST_NAME, m.MANAGER_ID , m.LAST_NAME
FROM employees as e
JOIN employees as m ON e.MANAGER_ID = m.EMPLOYEE_ID ;


-- 3 Scrivi una query per visualizazre nome, cognome, data di assunzione, stipendio del manager per tutti i manager con esperienza superiore a 15 anni.
SELECT FIRST_NAME, LAST_NAME, HIRE_DATE, SALARY
FROM departments d
JOIN employees e ON e.EMPLOYEE_ID = d.MANAGER_ID
WHERE datediff(NOW(), HIRE_DATE)> 15*365;


-- 4 Scrivi una query per trovare gli indirizzi di tutti i dipartimenti
SELECT LOCATION_ID, STREET_ADDRESS, CITY, STATE_PROVINCE, COUNTRY_NAME 
FROM locations l
JOIN countries c ON l.COUNTRY_ID = c.COUNTRY_ID;


-- 5 Scrivi una query per visualizzare la cronoloia del lavoro che e'stata eseguita da qualsiasi dipendente che attualmente sta lavorando piu di 10000 stipendio. 
SELECT j.EMPLOYEE_ID,j.START_DATE,j.END_DATE
FROM job_history j
JOIN employees e ON j.EMPLOYEE_ID = e.EMPLOYEE_ID
WHERE e.SALARY > 10000;




